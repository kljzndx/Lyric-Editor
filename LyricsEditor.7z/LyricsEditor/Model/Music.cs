﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.Storage.FileProperties;
using Windows.Storage.Pickers;
using Windows.UI.Xaml.Media.Imaging;

namespace LyricsEditor.Model
{
    class Music
    {
        /// <summary>
        /// 歌名
        /// </summary>
        public string Name { get; private set; }
        /// <summary>
        /// 歌手
        /// </summary>
        public string Artist { get; private set; }
        /// <summary>
        /// 音乐文件
        /// </summary>
        public StorageFile File { get; private set; }
        /// <summary>
        /// 音乐属性
        /// </summary>
        public MusicProperties Properties { get; private set; }
        /// <summary>
        /// 专辑图
        /// </summary>
        public BitmapImage AlbumImage { get; private set; }
        /// <summary>
        /// 打开音乐文件
        /// </summary>
        /// <returns>成功与否</returns>
        public async Task<bool> OpenFile()
        {
            FileOpenPicker picker = new FileOpenPicker { CommitButtonText = "打开此音乐" };
            picker.FileTypeFilter.Add(".mp3");
            picker.FileTypeFilter.Add(".flac");
            picker.FileTypeFilter.Add(".wav");
            picker.FileTypeFilter.Add(".aac");
            picker.FileTypeFilter.Add(".m4a");
            File = await picker.PickSingleFileAsync();
            if (File == null)
                return false;
            Properties = await File.Properties.GetMusicPropertiesAsync();
            Name = Properties.Title;
            Artist = Properties.Artist;
            await AlbumImage.SetSourceAsync(await File.GetThumbnailAsync(ThumbnailMode.MusicView));
            return true;
        }
    }
}
